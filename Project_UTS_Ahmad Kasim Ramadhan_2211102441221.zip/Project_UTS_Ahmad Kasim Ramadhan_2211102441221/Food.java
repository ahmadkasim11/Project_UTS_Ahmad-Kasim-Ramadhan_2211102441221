import greenfoot.*;

public class Food extends Actor
{
    public Food()
    {
        setImage("food.png"); // Ganti dengan nama file gambar makanan yang Anda inginkan
    }
}
