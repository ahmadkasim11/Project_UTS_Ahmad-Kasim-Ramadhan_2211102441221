import greenfoot.*;

public class SnakeSegment extends Actor
{
    public SnakeSegment(Snake snake)
    {
        setImage("snake_segment.png"); // Gambar segmen ular
    }
}
